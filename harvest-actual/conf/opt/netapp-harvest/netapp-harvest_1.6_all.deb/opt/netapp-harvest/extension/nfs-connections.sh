#! /bin/bash
# ==============================================================================
# NetApp Harvest Extensions
# ==============================================================================
#
# name:		nfs-connections.sh
#
# type:		bash script (main)
#
# purpose:	see PrintHelp function
#
# author:	Georg Mey
#
# ==============================================================================

export MY_PROJECT="NetApp Harvest Extensions"
export MY_NAME=`basename $0`
export TEST=false
export DASHES="----------------------------------------------------------------"

# ==============================================================================
# function:	    Write2Log
# parameter:	$1     = level
#               $2..$n = message to write to log
# purpose:	    Write log messages to file
# ==============================================================================
Write2Log() {

	LEVEL=`echo $1 | tr '[:lower:]' '[:upper:]'`

	if [ "$_HARVEST_VERBOSE" = "false" ] && [ "$LEVEL" = "DEBUG" ]; then
		return 1
	else
		TIME_STAMP=`date '+%Y-%m-%d %H:%M:%S'`
		shift
		printf "[%s] " "$TIME_STAMP"	>>$LOG_FILE
		printf "[%-7.7s] " $LEVEL	>>$LOG_FILE
		printf "%s\n" "$*"		>>$LOG_FILE
	fi

}

# ==============================================================================
# function:	GetClusterNodes
# parameter:	-none-
# purpose:	Get list of cluster nodes
# ==============================================================================
GetClusterNodes() {

	sshpass -p ${_HARVEST_PASSWORD} \
	ssh -o StrictHostKeyChecking=no \
	-l ${_HARVEST_USERNAME}  ${_HARVEST_HOSTNAME} \
	system node show -fields node 2>/dev/null | awk '

	BEGIN { DoPrint = 0 }

	$1 == "node"    { DoPrint = 1 ; getline ; getline }
	$1 ~ /^[0-9]+$/ { DoPrint = 0 }

	DoPrint == 1 { printf "%s\n",$1 } '

}

# ==============================================================================
# function:	GetNfsConnections
# parameter:	$1 - node name
# purpose:	Get number of NFS connections per node
# ==============================================================================
GetNfsConnections() {

	sshpass -p ${_HARVEST_PASSWORD} \
	ssh -o StrictHostKeyChecking=no \
	-l ${_HARVEST_USERNAME}  ${_HARVEST_HOSTNAME} \
	network connections active show -node $1 -service 'nfs*' \
	-fields remote-host  2>/dev/null | awk '

	BEGIN { DoPrint = 0 }

	$1 == "node"     { DoPrint = 1 ; getline ; getline }
	$1 ~ /^[0-9]+$/  { DoPrint = 0 }

	DoPrint == 1 { printf "%s\n",$4 } ' | wc -l

}

# ==============================================================================
# function:	GetNfsHosts
# parameter:	$1 - node name
# purpose:	Get number of uniq clients per node
# ==============================================================================
GetNfsHosts() {

	sshpass -p ${_HARVEST_PASSWORD} \
	ssh -o StrictHostKeyChecking=no \
	-l ${_HARVEST_USERNAME}  ${_HARVEST_HOSTNAME} \
	network connections active show -node $1 -service 'nfs*' \
	-fields remote-host  2>/dev/null | awk '

	BEGIN { DoPrint = 0 }

	$1 == "node"     { DoPrint = 1 ; getline ; getline }
	$1 ~ /^[0-9]+$/  { DoPrint = 0 }

	DoPrint == 1 { printf "%s\n",$4 } ' | sort | uniq | wc -l

}

# ==============================================================================
# function:	RunTheTask
# parameter:	-none-
# purpose:	Get data and send to Graphite
# ==============================================================================
RunTheTask() {


	NODES=`GetClusterNodes`

	for NODE in $NODES ; do

		ENTRY="$_HARVEST_GRAPHITE_ROOT"
		ENTRY="$ENTRY.node"
		ENTRY="$ENTRY.$NODE"
		ENTRY="$ENTRY.nfsv3"
		ENTRY="$ENTRY.nfs_connections"
		ENTRY="$ENTRY `GetNfsConnections $NODE`.0"
		ENTRY="$ENTRY $_HARVEST_POLL_EPOCH"

		Write2Log debug "M= $ENTRY"
		echo "$ENTRY" | nc -q 0 $_HARVEST_GRAPHITE_HOST 2003

		ENTRY="$_HARVEST_GRAPHITE_ROOT"
		ENTRY="$ENTRY.node"
		ENTRY="$ENTRY.$NODE"
		ENTRY="$ENTRY.nfsv3"
		ENTRY="$ENTRY.nfs_hosts"
		ENTRY="$ENTRY `GetNfsHosts $NODE`.0"
		ENTRY="$ENTRY $_HARVEST_POLL_EPOCH"

		Write2Log debug "M= $ENTRY"
		echo "$ENTRY" | nc -q 0 $_HARVEST_GRAPHITE_HOST 2003

	done

}

# ==============================================================================
# function:	RunTestOnly
# parameter:	-none-
# purpose:	Run a singel cycle for testing purposes withoutpu to STDOUT
# ==============================================================================
RunTestOnly() {

	NODES=`GetClusterNodes`

	printf "\n"
	printf "%-20.20s " "node"
	printf "%20.20s " "NFS-connections"
	printf "%20.20s " "NFS-clients"
	printf "\n"
	printf "%-20.20s " "$DASHES"
	printf "%20.20s " "$DASHES"
	printf "%20.20s " "$DASHES"
	printf "\n"

	for NODE in $NODES ; do

		printf "%-20.20s " "$NODE"
		printf "%20d " `GetNfsConnections $NODE`
		printf "%20d " `GetNfsHosts $NODE`
		printf "\n"

	done

	printf "\n"

}

# ==============================================================================
# function:	PrintHelp
# parameter:	-none-
# purpose:	show online help
# ==============================================================================
PrintHelp() {

	cat <<EOF_PRINT_HELP

   $MY_PROJECT - $MY_NAME

   usage:

      $MY_NAME [general options] [required options]

   general options:

      -h | --help
      -t | --test
      -v | --verbose

   required options:

      -H | --ghost            Fills environment variable _HARVEST_GRAPHITE_HOST
      -R | --ghroot           Fills environment variable _HARVEST_GRAPHITE_ROOT
      -G | --group            Fills environment variable _HARVEST_GROUP
      -C | --cluster          Fills environment variable _HARVEST_HOSTNAME
      -U | --user             Fills environment variable _HARVEST_USERNAME
      -P | --password         Fills environment variable _HARVEST_PASSWORD
      -I | --installdir       Fills environment variable _HARVEST_INSTALL_DIR
      -E | --epoch            Fills environment variable _HARVEST_POLL_EPOCH

EOF_PRINT_HELP

}

# ------------------------------------------------------------------------------
# runstring argument processing
# ------------------------------------------------------------------------------

TEMP=`getopt -o htvH:R:G:C:U:P:I:E: --long verbose,test,help,ghost:,groot:,group:,cluster:,user:,password:,installdir:,epoch: \
             -n "$MY_NAME" -- "$@"`

if [ $? != 0 ] ; then
	echo "$MY_NAME: see online help for details..." >&2
	PrintHelp
	exit 1
fi

eval set -- "$TEMP"

while true; do

	case "$1" in

    		-h | --help ) 		PrintHelp; exit 0 ;;
    		-t | --test ) 		TEST=true; shift ;;
    		-v | --verbose ) 	_HARVEST_VERBOSE=true; shift ;;
    		-H | --ghost ) 		_HARVEST_GRAPHITE_HOST="$2"; shift 2 ;;
    		-R | --groot ) 		_HARVEST_GRAPHITE_ROOT="$2"; shift 2 ;;
    		-G | --group ) 		_HARVEST_GROUP="$2"; shift 2 ;;
    		-C | --cluster ) 	_HARVEST_HOSTNAME="$2"; shift 2 ;;
    		-U | --user ) 		_HARVEST_USERNAME="$2"; shift 2 ;;
    		-P | --password ) 	_HARVEST_PASSWORD="$2"; shift 2 ;;
    		-I | --installdir )	_HARVEST_INSTALL_DIR="$2"; shift 2 ;;
    		-E | --epoch ) 		_HARVEST_POLL_EPOCH="$2"; shift 2 ;;
    		-- ) shift; break ;;
    		* ) break ;;

	esac

done

# ------------------------------------------------------------------------------
# check parameters
# ------------------------------------------------------------------------------
MISSING_PARAMETERS=""

if [ "$_HARVEST_GRAPHITE_HOST"  = "" ] ; then MISSING_PARAMETERS="$MISSING_PARAMETERS,ghost"      ; fi
if [ "$_HARVEST_GRAPHITE_ROOT"  = "" ] ; then MISSING_PARAMETERS="$MISSING_PARAMETERS,groot"      ; fi
if [ "$_HARVEST_GROUP"          = "" ] ; then MISSING_PARAMETERS="$MISSING_PARAMETERS,group"      ; fi
if [ "$_HARVEST_HOSTNAME"       = "" ] ; then MISSING_PARAMETERS="$MISSING_PARAMETERS,cluster"    ; fi
if [ "$_HARVEST_USERNAME"       = "" ] ; then MISSING_PARAMETERS="$MISSING_PARAMETERS,user"       ; fi
if [ "$_HARVEST_INSTALL_DIR"    = "" ] ; then MISSING_PARAMETERS="$MISSING_PARAMETERS,installdir" ; fi
if [ "$_HARVEST_PASSWORD"       = "" ] ; then MISSING_PARAMETERS="$MISSING_PARAMETERS,password"   ; fi
if [ "$_HARVEST_POLL_EPOCH"     = "" ] ; then MISSING_PARAMETERS="$MISSING_PARAMETERS,epoch"      ; fi

if [ "$MISSING_PARAMETERS" != "" ] ; then

	TEXT=${MISSING_PARAMETERS#*,}
	printf "\n"
	printf "%s: parameters \"%s\" not set, see -h for details\n" $MY_NAME "$TEXT"
	printf "\n"
	exit 2

fi

# Set verbose to false by default
if [ "$_HARVEST_VERBOSE" = "" ] ; then _HARVEST_VERBOSE=false ; fi

# Generate log filename
_HARVEST_CLUSTER=`echo $_HARVEST_GRAPHITE_ROOT | awk -F"." '{ print $(NF)}'`
_HARVEST_EXTENSION=`echo $MY_NAME | awk -F"." '{ print $(1)}'`
LOG_FILE="${_HARVEST_INSTALL_DIR}/log/${_HARVEST_CLUSTER}_netapp-harvest_${_HARVEST_EXTENSION}.log"

# Make sure sshpass is installed
if ! hash sshpass 2>/dev/null ; then
	printf "Warning: [sshpass] not installed, can't run package\n"
	Write2Log warning "[sshpass] not installed, can't run package [$MY_NAME], exiting"
	exit 1
fi

# ------------------------------------------------------------------------------
# main body of script
# ------------------------------------------------------------------------------

if [ "$TEST" = "true" ] ; then
	RunTestOnly
	exit 0
fi

Write2Log debug "Session started"

RunTheTask

Write2Log debug "Session ended"

exit 0

# ==============================================================================
# END OF SCRIPT
# ==============================================================================
