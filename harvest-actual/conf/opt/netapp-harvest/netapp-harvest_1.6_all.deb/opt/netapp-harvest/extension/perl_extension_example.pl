#!/usr/bin/perl

#
# Extension template for Harvest Extension Manager (HEM).
# Adapt to collect counter data and send to Graphite server.
#
# Extenions will usually run as a background process (initiated by HEM), in which case
# required parameters are provided by HEM as environment variables. For debugging
# or testing you can run plugin in foreground mode by providing required parameters
# as CLI arguments (For more details see PARAMETERS and DEBUGGING below).
#
#  HOW TO USE
# Template comes with two ready-to-use subroutines:
#       load_prepreq:       loads required parameters and opens log handler
#       send_to_graphite:   sends metric data to Graphite server
# and one subroutine that needs at least some adaptation:
#       render_metrics:     converts hashes into Graphite-acceptable metrics
#
# All you have to do is write the subroutine "collect_data": this subroutine should
# collect and process counters from any source, and store them as array of hashes.
#
#  PARAMETERS
# The following parameters will be stored in the hash "params" and are available
# to all subroutines. Normally, the program will read them from environment variables
# and you shouldn't worry about how to get them, but if you want to run the extension
# in foreground mode, make sure to provide them as CLI arguments (some or all of them).
#
#       - host                  ONTAP hostname or IP
#       - port                  ONTAP port
#       - user, pass            Credentials to access ONTAP host
#       - cluster               Name of ONTAP cluster
#       - group                 Name of ONTAP group
#       - harvest_dir           Path to Harvest installation directory
#       - timestamp             Timestamp of polling session / metrics
#       - verbose               Add debugging info to log if true
#       - graphite_host         Hostname of Graphite server
#       - graphite_port         Port to access Graphite server
#       - graphite_root         Prefix of metrics to be submitted to Graphite
#                               (e.g. "netapp.perf.group.cluster")
# Most of these parameters have default values, check subroutine load_prereqs
# for more details.
#
#  DEBUGGING
# For testing or debugging, it is most convenient to run the plugin in foreground
# mode. If you provide the plugin any CLI arguments, the script will automatically run
# in foreground mode (log messages are)
#
# Note: if "graphite_root" is not set (or is an emptry string), metrics will not
# be sent to Graphite.
#
#  EXAMPLE
# Run verbosely in foreground, but don't send metrics to Graphite:
#  $ ./perl_extension_example.pl -host 10.1.1.1 -user admin -pass mypassword \
#    -cluster mycluster -v
#
# Run verbosely in foreground, send metrics to Graphite at localhost:
#  $ ./perl_extension_example.pl -host 10.1.1.1 -user admin -pass mypassword \
#    -cluster mycluster -graphite_root "netapp.perf.AAA.mycluster" -v
#
# Run in HEM (add this command to template/extensions.conf):
#  "/opt/netapp-harvest/extension/perl_extension_example.pl"
#
# Author: Vachagan Gratian, NetApp 2019
# Contact: vachagan@netapp.com
#


require 5.10.0;
use strict;
use warnings;
use FindBin qw($Bin $Script);
use IO::Socket::INET;
use Getopt::Long;

# Add path to Harvest libs
# TODO: Change if Harvest installation is not in default path
use lib "/opt/netapp-harvest/local-lib";
use Logger;

# Pre-declare subroutines
sub load_prereqs;
sub collect_data;
sub render_metrics($@);
sub send_to_graphite($@);
sub logger($@);

# Holds all the important parameters we need to run plugin
my %params;
# Logger instance
my $logger;

# Load parameters from Environment variables or CLI
# This subroutine sets two global variables: "params" (hash) and logger (obj)
# TODO: expand subroutine to make some parameters required
load_prereqs();

# Print basic info
# TODO: you might want to change this message if data is not collected from ONTAP host
if ($params{background_mode})
{
    logger ("DEBUG", "Started new session. Will poll host [$params{host}:$params{port}] for data");
}
else
{
    logger ("NORMAL", "Started in foreground mode. Log messages are copied to console");
}

# Collect data and store it as an array of hash references
# TODO: most work has to be done in this subroutine
my @collected_data = collect_data();
logger ("DEBUG", "Collected ", scalar @collected_data, " counters");
logger ("DEBUG", "Ending session as there is no work to do") unless (@collected_data);
exit(1) unless (@collected_data);

# Counters need to be formatted into strings (leafs) that will be accepted by Graphite server
# Subroutine expects array of hashes, with at least the items "node", "counter" and "value"
# TODO: you need to adapt subroutine to get a Graphite leaf that fits into the logic of your counters
# and your Graphite database hierarchy.
my @ready_to_send = render_metrics(\@collected_data);
logger ("DEBUG", "Rendered ", scalar @ready_to_send, " metrics ready to be sent");

# Finally your metrics can be sent to Graphite server
send_to_graphite(\@ready_to_send);
logger ("DEBUG", "Ending session");


##
## Collect data and process them if necessary
##
sub collect_data()
{
    my @data;

    # TODO: your code that collects counters from any source (ONTAP ZAPI, Rest API or third party sources)

    # For playing around you can generate some dummy counters:
    # (this creates an array of 5 hash refs, each hash with the three items "node", "counter", "value")
	# @data = map { { "node" => "my_node", "counter" => "my_counter", "value" => $_ } } (0..4);

    return @data;
}

##
## Format an array of hashes into an array of strings that can be sent to Graphite server
##
sub render_metrics($@)
{
    my $raw_metrics = shift;
    my @rendered_metrics;

    foreach my $hash (@$raw_metrics)
    {
        # TODO: Adapt to your preferred metric style.
        # This example renders the following Graphite leaf:
        # ROOT.node.NODE.COUNTER VALUE TIMESTAMP
        my $metric_leaf = $params{graphite_root} . ".node." . $hash->{node} . ".";
        $metric_leaf .= $hash->{counter} . " " . $hash->{value} . " " . $params{timestamp};

        logger ("DEBUG", "M= $metric_leaf");
        push @rendered_metrics, $metric_leaf;
    }
    return @rendered_metrics;
}


##
## Open socket to Graphite server and send metrics
##
sub send_to_graphite($@)
{
    my $metrics_to_send = shift;

    if ((! exists $params{graphite_host}) || ($params{graphite_root} eq "") )
    {
        logger ("DEBUG", "Sending to graphite not enabled, skipping send");
        return 0;
    }

    # Partially copied from netapp-worker, written by Chris Madden
    my $retries = 2;
    my $socket_obj;
    my $socket_err = '';

    while ($retries)
    {
        $socket_err = ''; # Reset socket error reason


        # Open socket to Graphite server
        logger ("DEBUG", "Issuing new socket connect to Graphite server [$params{graphite_host}:$params{graphite_port}/tcp].");
        $socket_obj = IO::Socket::INET->new(
                      PeerAddr => $params{graphite_host},
                      PeerPort => $params{graphite_port},
                      Timeout => '5',
                      Proto    => 'tcp');
        # If we failed give up
        if (! defined $socket_obj)
        {
            $socket_err = $! || 'failed without a specific library error';
            logger ("DEBUG", "New socket connect failure with reason: [$socket_err]");
            last;
        }

        # Assume success and send
        foreach my $metric (@$metrics_to_send)
        {
            if ( ! defined $socket_obj->send("$metric\n") )
            {
                $socket_err = $! || 'failed without a specific library error';
                logger ("DEBUG", "Socket failure with reason: [$socket_err]");
                $retries--;
                undef $socket_obj;
                last;
            }
        }
        # Exit loop if we have no socket error
        $retries = 0 if ($socket_err eq '');
    }
    if ($socket_err ne '')
    {
        logger ("WARNING", "Metrics NOT sent to Graphite. Cannot establish/maintain a connection to [$params{graphite_host}:$params{graphite_port}/tcp]: $socket_err");
        return -1;
    }

    logger("DEBUG", "Successfully sent ", scalar @$metrics_to_send, " metrics to Graphite server");
    return 0;
}


##
## This subroutine should take care of the prerequisites for running the extension.
##
## First we load parameters and decide whether to run in background mode or not.
## If parameters are provided as CLI arguments, we run in foreground mode, otherwise
## we expect them as environment variables and run in background mode.
##
## Secondly, we open a Logger instance which will handle our log messages (those will
## be copied to STDOUT if in foreground mode).
##
sub load_prereqs()
{

    # If parameters are in ARGV, load from there and run in foreground mode
    if ($#ARGV > 0) {
        GetOptions( \%params, "host:s", "port:i", "user:s", "pass:s", "cluster:s", "group:s", "graphite_host:s",
            "graphite_port:i", "graphite_root:s", "harvest_dir:s", "timestamp:i", "verbose|v" );

        # Set default values
        $params{port} = 443 unless (exists $params{port});
        $params{cluster} = "Cluster" unless (exists $params{cluster});
        $params{graphite_host} = "localhost" unless (exists $params{graphite_host});
        $params{graphite_port} = 2003 unless (exists $params{graphite_port});
        $params{graphite_root} = "." unless (exists $params{graphite_root});
        $params{harvest_dir} = "/opt/netapp-harvest/" unless (exists $params{harvest_dir});
        $params{timestamp} = time() unless (exists $params{timestamp});
        $params{verbose} = 0 unless (exists $params{verbose});
        $params{background_mode} = 0;
    }
    # Otherwise assume params are in env variables and run in background mode
    else {
        $params{verbose} =       $ENV{_HARVEST_VERBOSE}         || 0;
        $params{group} =         $ENV{_HARVEST_GROUP}	        || "";
        $params{cluster} =       $ENV{_HARVEST_CLUSTER}	        || "";
        $params{port} =          $ENV{_HARVEST_PORT}	        || 443;
        $params{host} =          $ENV{_HARVEST_HOSTNAME}	    || "";
        $params{user} =          $ENV{_HARVEST_USERNAME}	    || "";
        $params{pass} =          $ENV{_HARVEST_PASSWORD}	    || "";
        $params{graphite_root} = $ENV{_HARVEST_GRAPHITE_ROOT}	|| ".";
        $params{graphite_host} = $ENV{_HARVEST_GRAPHITE_HOST}	|| "localhost";
        $params{graphite_port} = $ENV{_HARVEST_GRAPHITE_PORT}	|| 2003;
        $params{harvest_dir} =   $ENV{_HARVEST_INSTALL_DIR}	    || "/opt/netapp-harvest/";
        $params{timestamp} =     $ENV{_HARVEST_POLL_EPOCH}	    || time();
        $params{background_mode} = 1;
    }

    # TODO: if you need to make some parameters mandatory, you can do that here

    # Make sure harvest path ends with slash
    $params{harvest_dir} .= "/" unless( (substr $params{harvest_dir}, -1) eq "/");

    # Make sure graphite root does not end with a dot
    chop $params{graphite_root} if( (substr $params{graphite_root}, -1) eq ".");

    # Add options that are expected by Logger
    my %options;
    $options{v} = 1  if ($params{verbose} == 1);
    $options{poller} = $params{cluster} . "_netapp-harvest";
    $options{conf}   = $Script;
    $options{conf}   =~ s/\.pl//g;
    $logger = Logger->new(($params{harvest_dir} . "log"), \%options);

}

## Delegate log messages to Logger
sub logger($@)
{
    $logger->logger(@_);
}
