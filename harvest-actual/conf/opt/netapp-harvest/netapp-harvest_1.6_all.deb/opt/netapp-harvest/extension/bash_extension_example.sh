#! /bin/bash

# ==============================================================================
# Extension template for NetApp Harvest Manager (HEM)
#
# Adapt this script to collect counter data and send to Graphite server
#
# HOW TO USE:
# Template includes 4 ready-to-use functions:
#   - PrintHelp       Outputs detailed usage info
#   - LoadParameters  Loads parameters from CLI/env variables, opens Log
#   - Write2Log       Writes message to log or prints to console (in test mode)
#   - Send2Graphite   Sends metric to Graphite server
# The following function needs to be written (almost from scratch)
#   - RunTheTask      Should collect counter data and format them into metric
#                     strings (as Graphite leafs)
#
# Script can be run either as a background process (normally by HEM) or in the
# foreground (mainly for testing and debugging). Parameters are read from either
# from environment variables or command-line arguments, if both are available
# command-line arguments will be used.
#
# Metrics will not be sent to Graphite when running in test mode ("-t")
#
# For a list of required parameters and available options, run with "-h"
# (You might want to change in LoadParameters what parameters should be
# required)
#
# Authors:	Georg Mey, Vachagan Gratian. (c) NetApp 2019
#
# ==============================================================================


export MY_PROJECT="NetApp Harvest Extension"
export MY_NAME=`basename $0`
export TEST=false


Main() {

    # Load our parameters from env variables or CLI
    LoadParameters $@

    # Print basic info about session
    if [ "$TEST" = "true" ] ; then
        Write2Log warning "Starting session in test mode, logs are forwarded to console and no metrics will be sent to Graphite"
    else
        Write2Log debug "Started extension session normally"
    fi

    # Run the task: collect counters and send to Graphite
    # TODO: currently this is an incomplete function and you need to expand it yourself!
    RunTheTask

    # We are done if we reached this far
    Write2Log debug "Session ended normally"
    exit 0
}


# ==============================================================================
# function:	    RunTheTask
# parameter:	-none-
# purpose:	    Get data and send to Graphite
# ==============================================================================
RunTheTask() {

    # Say you want to collect some counters on Node level
    # First you'll need to write a function that gets a list of your nodes, e.g.:
    # NODES=GetClusterNodes
    NODES="node0 node1 node2"

    # Iterate over each node and collect some counters
    for NODE in $NODES; do
        # Preconstruct Graphite leaf
        METRIC="$_HARVEST_GRAPHITE_ROOT.node.$NODE.my_counter"

        # Write a function that gets the counter value for the given node, e.g.
        # VALUE=GetCounter $NODE
        VALUE="0.0"

        # Complete the Graphite leaf
        METRIC="$METRIC $VALUE $_HARVEST_POLL_EPOCH"

        # Send metric to Graphite
        Send2Graphite "$METRIC"

    done
}


# ==============================================================================
# function:	    Send2Graphite
# parameter:	-none-
# purpose:	    Send a single metric to Graphite
# ==============================================================================
Send2Graphite() {
    Write2Log debug "M=" "$1"
    # Only send if not in test mode
    if [ "$TEST" != "true" ] ; then
        echo "$1" | nc -q 0 $_HARVEST_GRAPHITE_HOST 2003
    fi
}


# ==============================================================================
# function:	    LoadParameters
# parameter:	-none-
# purpose:	    Read and validate parameters from CLI arguments
#               Open Log file if not in test mode
# ==============================================================================
LoadParameters() {

    # Read CLI arguments
    TEMP=`getopt -o htvH:R:G:C:U:P:I:E: --long verbose,test,help,ghost:,groot:,group:,cluster:,user:,password:,installdir:,epoch: \
                 -n "$MY_NAME" -- "$@"`

    # Warn for invalid arguments
    if [ $? != 0 ] ; then
    	echo "$MY_NAME: see online help for details..." >&2
    	PrintHelp
    	exit 1
    fi

    eval set -- "$TEMP"

    # Store loaded parameters
    while true; do

    	case "$1" in

        		-h | --help ) 		PrintHelp; exit 0 ;;
        		-t | --test ) 		TEST=true; shift ;;
        		-v | --verbose ) 	_HARVEST_VERBOSE=true; shift ;;
        		-H | --ghost ) 		_HARVEST_GRAPHITE_HOST="$2"; shift 2 ;;
        		-R | --groot ) 		_HARVEST_GRAPHITE_ROOT="$2"; shift 2 ;;
        		-G | --group ) 		_HARVEST_GROUP="$2"; shift 2 ;;
        		-C | --cluster ) 	_HARVEST_HOSTNAME="$2"; shift 2 ;;
        		-U | --user ) 		_HARVEST_USERNAME="$2"; shift 2 ;;
        		-P | --password ) 	_HARVEST_PASSWORD="$2"; shift 2 ;;
        		-I | --installdir )	_HARVEST_INSTALL_DIR="$2"; shift 2 ;;
        		-E | --epoch ) 		_HARVEST_POLL_EPOCH="$2"; shift 2 ;;
        		-- ) shift; break ;;
        		* ) break ;;

    	esac
    done

    # Check for missing parameters
    # TODO: customize which parameters are mandatory and which not
    MISSING_PARAMETERS=""

    if [ "$_HARVEST_GRAPHITE_HOST"  = "" ] ; then MISSING_PARAMETERS="$MISSING_PARAMETERS,ghost"      ; fi
    if [ "$_HARVEST_GRAPHITE_ROOT"  = "" ] ; then MISSING_PARAMETERS="$MISSING_PARAMETERS,groot"      ; fi
    if [ "$_HARVEST_GROUP"          = "" ] ; then MISSING_PARAMETERS="$MISSING_PARAMETERS,group"      ; fi
    if [ "$_HARVEST_HOSTNAME"       = "" ] ; then MISSING_PARAMETERS="$MISSING_PARAMETERS,cluster"    ; fi
    if [ "$_HARVEST_USERNAME"       = "" ] ; then MISSING_PARAMETERS="$MISSING_PARAMETERS,user"       ; fi
    if [ "$_HARVEST_INSTALL_DIR"    = "" ] ; then MISSING_PARAMETERS="$MISSING_PARAMETERS,installdir" ; fi
    if [ "$_HARVEST_PASSWORD"       = "" ] ; then MISSING_PARAMETERS="$MISSING_PARAMETERS,password"   ; fi
    if [ "$_HARVEST_POLL_EPOCH"     = "" ] ; then MISSING_PARAMETERS="$MISSING_PARAMETERS,epoch"      ; fi

    if [ "$MISSING_PARAMETERS" != "" ] ; then

    	TEXT=${MISSING_PARAMETERS#*,}
    	printf "\n"
    	printf "Missing required parameters: [%s], see -h for details\n" "$TEXT"
    	printf "\n"
    	exit 2
    fi

    # Set verbose to false by default
    if [ "$_HARVEST_VERBOSE" = "" ] ; then _HARVEST_VERBOSE=false ; fi

    # Generate log filename if not running in test mode
    if [ "$TEST" != "true" ] ; then

        _HARVEST_CLUSTER=`echo $_HARVEST_GRAPHITE_ROOT | awk -F"." '{ print $(NF)}'`
        _HARVEST_EXTENSION=`echo $MY_NAME | awk -F"." '{ print $(1)}'`
        LOG_FILE="${_HARVEST_INSTALL_DIR}/log/${_HARVEST_CLUSTER}_netapp-harvest_${_HARVEST_EXTENSION}.log"
    fi
}


# ==============================================================================
# function:	    Write2Log
# parameter:	$1     = level
#               $2..$n = message to write to log
# purpose:	    Write log messages to file. Or, if we have no log file
#               print messages to console
# ==============================================================================
Write2Log() {

    # Uppercase level
	LEVEL=`echo $1 | tr '[:lower:]' '[:upper:]'`

    # Neglect debug messages if not requested
	if [ "$_HARVEST_VERBOSE" = "false" ] && [ "$LEVEL" = "DEBUG" ]; then
		return 1
	else
		TIME_STAMP=`date '+%Y-%m-%d %H:%M:%S'`
		shift

        # Send to log file if we have one
        if [ "$LOG_FILE" != "" ]; then
    		printf "[%s] "    "$TIME_STAMP"   >>$LOG_FILE
    		printf "[%-7.7s] " $LEVEL         >>$LOG_FILE
    		printf "%s\n"     "$*"		      >>$LOG_FILE
        else
            printf "[%s] "    "$TIME_STAMP"
            printf "[%-7.7s] " $LEVEL
            printf "%s\n"     "$*"
        fi
	fi

}


# ==============================================================================
# function:	    PrintHelp
# parameter:	-none-
# purpose:	    show online help
# ==============================================================================
PrintHelp() {

	cat <<EOF_PRINT_HELP

   $MY_PROJECT - $MY_NAME

   usage:

      $MY_NAME [general options] [required options]

   general options:

      -h | --help
      -t | --test
      -v | --verbose

   required options:

      -H | --ghost            Fills environment variable _HARVEST_GRAPHITE_HOST
      -R | --ghroot           Fills environment variable _HARVEST_GRAPHITE_ROOT
      -G | --group            Fills environment variable _HARVEST_GROUP
      -C | --cluster          Fills environment variable _HARVEST_HOSTNAME
      -U | --user             Fills environment variable _HARVEST_USERNAME
      -P | --password         Fills environment variable _HARVEST_PASSWORD
      -I | --installdir       Fills environment variable _HARVEST_INSTALL_DIR
      -E | --epoch            Fills environment variable _HARVEST_POLL_EPOCH

EOF_PRINT_HELP

}


Main $@
