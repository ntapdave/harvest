#!/usr/bin/python

"""
Extension template for Harvest Extension Manager (HEM).
Adapt to collect counter data and send to Graphite server.

 HOW TO USE:
Template includes two ready-to-use methods:
    - load_prereqs:         loads required parameters and opens log handler
    - send_to_graphite:     sends metrics to Graphite server
And one method that needs at least some adaptation:
    - render_metric:        format metric to be acceptable by Graphite

All you need to do, is to write the method "collect_data": it should collect
(and possibly process) counter data from any source of your choice (either
an ONTAP system or a third-party system) and store it as a list of hashes. You
also need to slightly adapt the method "render_metric", such that your metrics
are stored by Graphite in a hierarchy that makes sense to you (and Grafana).
See under "render_metrics()" for more details.

 PYTHON COMPATIBILITY:
This script, as it is now, is compatible with both Python 2 and 3. It is
recommended to restrict your script to a specific Python version.

 PARAMETERS:
The following variables are provided by HEM and they will be read and stored
in the global dict "params":
    - host                  ONTAP hostname or IP
    - port                  ONTAP port
    - user, pass            Credentials to access ONTAP host
    - cluster               Name of ONTAP cluster
    - group                 Name of ONTAP group
    - harvest_dir           Path to Harvest installation directory
    - timestamp             Timestamp for our metrics
    - verbose               Add debugging info to log if true
    - graphite_host         Hostname of Graphite server
    - graphite_port         Port to access Graphite server
    - graphite_root         Prefix of metrics to be submitted to Graphite
                            (e.g. "netapp.perf.group.cluster")

Most of these parameters have default values, if not provided, check
"load_prereqs" for more details.

Additionally the parameter "background_mode" tells you in which mode the script
wants to run (the foreground mode is mainly intended for debugging, see below).

 DEBUGGING:
For debugging you can run the script in foreground mode. If CLI arguments are
provided, the script will automatically run in foreground mode and log messages
will be forwarded to STDOUT. The script expects in this case, that necessary
parameters are provided as CLI arguments.

If "graphite_root" is not provided in CLI, no data will be sent to Graphite.
Use this for (dirty) debugging.

 EXAMPLES:
Run verbosely in foreground, but don't send metrics to Graphite:
  $ ./python_extension_example.py -host 10.1.1.1 -user admin -pass password \
    -cluster mycluster -v
Run verbosely in foreground, send to Graphite at localhost:
  $ ./python_extension_example.py -host 10.1.1.1 -user admin -pass password \
   -cluster mycluster -graphite_root "netapp.perf.AAA.mycluster" -v
Run in HEM (add this command to template/extensions.conf):
  "/opt/netapp-harvest/extension/python_extension_example.py"


Author: Vachagan Gratian, NetApp 2019
Contact: vachagan@netapp.com

"""

import os
import sys
import time
import socket
import time
import logging


def main():

    # Load required variables/parametres and open log file
    # This methods sets two global variables: "params" (dict) and logger (obj)
    # TODO: you might change what parameters should be expected or required
    load_prereqs()

    # Basic info
    if params['background_mode']:
        logger.debug('[main] Started new session. Will poll host [{}] for ' \
            'counter data'.format(params['host']))
    else:
        logger.info('[main] Started session in foreground mode. Log ' \
            'messages will be forwarded to console')

    # Collect data and store it as a list of dicts
    collected_data = collect_data()

    # After you collected your data, it needs to be in Graphite-accepted format
    # Assuming collected_data is a list of dicts and each dict has the three
    # items "node", "counter", "value", this one liner will do the work
    ready_to_send = [render_metric(**metric) for metric in collected_data]
    # TODO: Adapt render_metrics, to use a proper Graphite path!

    # Finally your data can be sent to Graphite server
    send_to_graphite(ready_to_send)

    logger.debug('[main] Ending session')


def collect_data():

    collected_data = []
    # TODO Write your code to collect data

    # For playing around you can generate some dummy counters:
    # collected_data = [{'node': 'dummy_node', 'counter': 'dummy_counter', 'value':i} for i in range(5)]

    return collected_data


def load_prereqs():
    """
    Load polling parameters from either envirment variables or CLI arguments.
    Finally open log handler.

    """

    global params
    params = {}

    # If no command line arguments, run in default mode, i.e. collect
    # parameters from environment variables and run in background mode
    if len(sys.argv) == 1:
        params['cluster'] = os.getenv('_HARVEST_CLUSTER', '')
        params['group'] = os.getenv('_HARVEST_GROUP', None)
        params['host'] = os.getenv('_HARVEST_HOSTNAME', None)
        params['port'] = int(os.getenv('_HARVEST_PORT', 443))
        params['user'] = os.getenv('_HARVEST_USERNAME', None)
        params['pass'] = os.getenv('_HARVEST_PASSWORD', None)
        params['graphite_root'] = os.getenv('_HARVEST_GRAPHITE_ROOT', None)
        params['graphite_host'] = os.getenv('_HARVEST_GRAPHITE_HOST', 'localhost')
        params['graphite_port'] = int(os.getenv('_HARVEST_GRAPHITE_PORT', 2003))
        params['harvest_dir'] = os.getenv('_HARVEST_INSTALL_DIR', '/opt/netapp-harvest/')
        params['timestamp'] = os.getenv('_HARVEST_POLL_EPOCH', round(time.time()))
        params['verbose'] = int(os.getenv('_HARVEST_VERBOSE', 0))
        params['background_mode'] = True

    # Get parameters from command line arguments and run in foreground
    # Note: if graphite_root is not provided, default value "_" is used,
    # this will tell send_to_graphite NOT to send the metrics to Graphite
    else:
        import argparse
        p = argparse.ArgumentParser()
        p.add_argument('-host')
        p.add_argument('-user')
        p.add_argument('-pass')
        p.add_argument('-port', type=int, default=443)
        p.add_argument('-cluster', default='CLUSTER')
        p.add_argument('-group', default=None)
        p.add_argument('-graphite_host', default='localhost')
        p.add_argument('-graphite_port', type=int, default=2003)
        p.add_argument('-graphite_root', default='_')
        p.add_argument('-harvest_dir', default='/opt/netapp-harvest/')
        p.add_argument('-timestamp', type=int, default=round(time.time()))
        p.add_argument('-v', action='store_true', dest='verbose', default=False)
        params = vars(p.parse_args())
        params['background_mode'] = False

    # Make sure path ends with slash
    if params['harvest_dir'][-1] != '/':
        params['harvest_dir'] = params['harvest_dir'] + '/'

    # Make sure Graphite has no trailing dot
    if params['graphite_root'] and params['graphite_root'][-1] == '.':
        params['graphite_root'] = parmas['graphite_root'][:-1]

    # Get module name, we'll use this to compose a name for the log file
    my_name = sys.argv[0].split('/')[-1]
    my_name = my_name.replace('.py', '') if my_name.endswith('.py') else my_name

    # Open a log file
    # Logging level is set to "debug" if verbose is true, otherwise "info".
    # If "background_mode" is false, log messages will be redirected to STDOUT.
    global logger
    logger = logging.getLogger(my_name)
    if params['background_mode']:
        logger_path = '{}log/{}_netapp-harvest_{}.log' \
            ''.format(params['harvest_dir'], params['cluster'], my_name)
        logging.basicConfig(
            filename = logger_path,
            level = logging.DEBUG if params['verbose'] else logging.INFO,
            format='[%(asctime)s] [%(levelname)s] %(message)s' )
    # If we run in foreground, redirect log messages to stdout
    else:
        logging.basicConfig(
            stream = sys.stdout,
            level = logging.DEBUG if params['verbose'] else logging.INFO,
            format='[%(asctime)s] [%(levelname)s] %(message)s' )


def render_metric(node, counter, value):
    """
    Graphite expects a byte array, in the format:
    'COUNTER_PATH VALUE TIMESTAMP\n'

    Counter path is a dot-seperated value, starting with graphite_root
    (e.g. 'netapp.perf.GROUP.mycluster.mynode-01') and ending with the 
    counter name (e.g. 'avg_latency').

    Make sure to adapt the variables of the counter path and consequently
    the arguments of this method!
    """
    metric = "{ROOT}.node.{NODE}.example.{COUNTER} {VALUE} {TS}\n".format (
            ROOT = params['graphite_root'],
            NODE = node,
            COUNTER = counter,
            VALUE = value,
            TS = params['timestamp'] )
    # Python 3 stores strings as unicode by default
    # so convert to byte array which is required by socket
    if sys.version_info >= (3,0):
        metric = metric.encode()
    logger.debug('[render_metric] metric={}'.format(metric[:-1]))
    return metric


def send_to_graphite(metrics_to_send, is_retry=False):
    """
    Open socket to Graphite server and send the metrics. If opening socket
    fails, retry one more time.
    """

    # If we have no graphite root defind, we can't send metrics
    # If root is "_", user doesn't ask to send metrics.
    if 'graphite_root' not in params or params['graphite_root'] == '_':
        logger.debug('[send_to_graphite] Skipping send metrics to graphite')
        return

    # Same if there are no metrics to send
    if not metrics_to_send:
        logger.debug('[send_to_graphite] Nothing to send')
        return

    # Open socket to Graphite server
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        sock.connect((params['graphite_host'], params['graphite_port']))
    except Exception as ex:
        logger.error('[send_to_graphite] Error while opening socket to ' \
            'Graphite [{}:{}]: {}'.format( params['graphite_host'],
                                           params['graphite_port'],
                                           ex) )
        # Retry one more time
        if not is_retry:
            send_to_graphite(metrics_to_send, is_retry=True)
        else:
            logger.error('[send_to_graphite] Retry failed, so exiting')
            sys.exit(1)
    else:
        logger.debug('[send_to_graphite] Opened socket to Graphite ' \
                '[{}:{}]'.format( params['graphite_host'],
                                  params['graphite_port']) )

    # Remove timeout to get back to blocking mode
    sock.settimeout(None)

    # Send metrics
    success = 0
    failed = 0
    for metric in metrics_to_send:
        try:
            response = sock.sendall(metric)
        except Exception as ex:
            logger.warning('[send_to_graphite] Error while sending metric: ' \
                '{}'.format(ex))
            failed += 1
        else:
            if response:
                logger.warning('[send_to_graphite] Failed to send metric: ' \
                    '{}'.format(ex))
                failed += 1
            else:
                success += 1

    # Close socket
    sock.shutdown(socket.SHUT_WR)
    sock.close()

    logger.debug('[send_to_graphite] Successfully sent: {}, failed: {}'.format \
        (success, failed))


if __name__ == '__main__':
    main()
