#!/usr/bin/python

"""
Extension plugin for NatApp Harvest. Collects SnapMirror Relationships and
sends to Graphite.


 REQUIREMENTS:
    - NetApp SDK Python package (in HARVEST_INSTALL_DIR/lib/)
    - Compatible with Python 2 and 3.

 USAGE
Plugin is intended to be run as background process by Harvest Extension Manager
in which case the required parameters are passed on as environment variables.
However plugin can also be run in foreground by providing the required
parameters as command-line arguments.

 PARAMETERS:
Normally required parameters are expected to be found as environment
variables. These are:

 REQUIRED:
    _HARVEST_HOSTNAME       - hostname of ONTAP system
    _HARVEST_USERNAME       - username to access ONTAP
    _HARVEST_PASSWORD       - password to access ONTAP
    _HARVEST_CLUSTER        - Name of ONTAP Cluster
    _HARVEST_GRAPHITE_ROOT  - prefix of metrics we send to Graphite
                              (usually: 'netapp.perf.GROUP.CLUSTER')
 OPTIONAL:
    _HARVEST_VERBOSE        - add debugging info to log, default: False
    _HARVEST_INSTALL_DIR   - Harvest path, default: '/opt/netapp-harvest/'
    _HARVEST_PORT           - port of ONTAP system, default: 443
    _HARVEST_GRAPHITE_HOST  - Graphite server hostname, default: localhost
    _HARVEST_GRAPHITE_PORT  - Graphite server port, default: 2003

If you want to run package in foreground, you can pass these parameters
as command line arguments:

 REQUIRED:
    -host                   - hostname / IP of ONTAP system
    -user                   - username to access ONTAP
    -pass                   - password

 OPTIONAL:
    -cluster                - ONTAP Cluster name, default: 'CLUSTER'
    -port                   - ONTAP port, defualt: 443
    -graphite_root          - prefix of metric path, if not provided,
                              no metrics will be send to Graphite
    -graphite_host          - Graphite server hostname, default: localhost
    -graphite_port          - Graphite server port, default: 2003
    -harvest_dir            - Harvest directory, default: '/opt/netapp-harvest/'
    -v                      - More stdout


 COLLECTED METRICIS:
Metrics are counts of destination and source replications per Node
and are stored by their status by the time of polling (idle, insync...).
Additionally two counters, src_meter_count and dest_meter_count, show
the limit of active replications on the ONTAP system.

 WORKFLOW:
Performs three subsequent ZAPI calls to the ONTAP host:
- Gets list of SnapMirror Relationships (associated to a volume or node)
- Gets nodes the volumes belong to
- Gets src_meter_count and dest_meter_count of nodes
Finally, opens TCP socket to send the metrics to Graphite

 LOGGING:
Logging file will be opened in subfolder "log/" of the Harvest installation
dir. File name is Cluster + "_netapp-harvest_snapmirror-replications.log".

Running in foreground mode will send everything to STDOUT.

 Author: Vachagan Gratian, NetApp 2019
 Contact: vachagan@netapp.com

"""

import os
import sys
import time
import socket
import time
import logging

def main():

    # Load required variables and libs
    load_prereqs()

    # Basic info
    if params['background_mode']:
        logger.debug('[main] Started new session. Will poll host [{}] for ' \
            'SnapMirror replications'.format(params['host']))
    else:
        logger.info('[main] Started session in foreground mode. Log ' \
            'messages will be forwarded to console')

    # Establish ZAPI connection to the host
    connect_zapi()

    # We'll get snapmirror relationships per node or volume
    poll_snapmirrors()

    # Get node for instances of which we don't know the node
    poll_nodes()

    # Get the limit of active replications for each node
    poll_meters()

    # Convert data to format we can send to Graphite
    render_graphite_metrics()

    # Send to Graphite server
    send_to_graphite()

    logger.debug('[main] Ending session')


def load_prereqs():
    """
    Load envirmental variables and NetApp SDK python lib which are required
    to run this package. Exit if fails. Open log file if success.

    """

    global params
    params = {}

    # If no command line arguments, run in default mode, i.e. collect
    # parameters from environment variables and run in background mode
    if not len(sys.argv) > 1:
        params['cluster'] = os.getenv('_HARVEST_CLUSTER', '')
        params['host'] = os.getenv('_HARVEST_HOSTNAME', None)
        params['port'] = int(os.getenv('_HARVEST_PORT', 443))
        params['user'] = os.getenv('_HARVEST_USERNAME', None)
        params['pass'] = os.getenv('_HARVEST_PASSWORD', None)
        params['graphite_root'] = os.getenv('_HARVEST_GRAPHITE_ROOT', None)
        params['graphite_host'] = os.getenv('_HARVEST_GRAPHITE_HOST', 'localhost')
        params['graphite_port'] = int(os.getenv('_HARVEST_GRAPHITE_PORT', 2003))
        params['harvest_dir'] = os.getenv('_HARVEST_INSTALL_DIR', '/opt/netapp-harvest/')
        params['verbose'] = int(os.getenv('_HARVEST_VERBOSE', 0))
        params['background_mode'] = True
    # Get parameters from command line arguments and run in foreground
    else:
        import argparse
        p = argparse.ArgumentParser()
        p.add_argument('-host')
        p.add_argument('-user')
        p.add_argument('-pass')
        p.add_argument('-port', type=int, default=443)
        p.add_argument('-cluster', default='CLUSTER')
        p.add_argument('-graphite_host', default='localhost')
        p.add_argument('-graphite_port', type=int, default=2003)
        p.add_argument('-graphite_root', default='_')
        p.add_argument('-harvest_dir', default='/opt/netapp-harvest/')
        p.add_argument('-v', action='store_true', dest='verbose', default=False)
        params = vars(p.parse_args())
        params['background_mode'] = False

    # Make sure path ends with slash
    if params['harvest_dir'][-1] != '/':
        params['harvest_dir'] = params['harvest_dir'] + '/'

    # Make sure Graphite has no trailing dot
    if params['graphite_root'] and params['graphite_root'][-1] == '.':
        params['graphite_root'] = parmas['graphite_root'][:-1]

    # Get module name, we'll use this to compose a name for the log file
    my_name = sys.argv[0].split('/')[-1]
    my_name = my_name.replace('.py', '') if my_name.endswith('.py') else my_name

    # Open Logging file
    global logger
    logger = logging.getLogger(my_name)
    if params['background_mode']:
        logger_path = '{}log/{}_netapp-harvest_{}.log' \
            ''.format(params['harvest_dir'], params['cluster'], my_name)
        logging.basicConfig(
            filename = logger_path,
            level = logging.DEBUG if params['verbose'] else logging.INFO,
            format='[%(asctime)s] [%(levelname)s] %(message)s' )
    # If we run in foreground, redirect log messages to stdout
    else:
        logging.basicConfig(
            stream = sys.stdout,
            level = logging.DEBUG if params['verbose'] else logging.INFO,
            format='[%(asctime)s] [%(levelname)s] %(message)s' )

    # Verify that all required parameters are present
    missing_required = False
    for p in ('host', 'user', 'pass', 'cluster', 'graphite_root'):
        if p not in params or not params[p]:
            logger.warning('[load_prereqs] Missing parameter: {}'.format(p))
            missing_required = True

    if missing_required:
        logger.warning('[load_prereqs] Terminating')
        sys.exit(0)


    # Import SDK python package
    sys.path.append(params['harvest_dir'] + 'lib/')
    sys.path.append(params['harvest_dir'] + 'lib/python')
    global SDK
    try:
        import NaServer as SDK
    except ImportError as err:
        logger.error('[load_prereqs] Failed to import NaServer: {}'.format(err))
        logger.error('[load_prereqs] Make sure NetApp SDK python package is ' \
                'available in {}lib/. Exiting'.format(harvest_dir))
        sys.exit(1)


def connect_zapi(max_time=5):
    """
    Create ZAPI connection to Server

    """
    global zapi

    try:
        zapi = SDK.NaServer(params['host'], 1, 3)
        zapi.set_server_type('FILER')
        zapi.set_transport_type('HTTPS')
        zapi.set_style('LOGIN')
        zapi.set_timeout(max_time)
        zapi.set_admin_user(params['user'], params['pass'])
    except Exception as ex:
        logger.warning('[connect_zapi] Failed setting up NaServer: {}'.format(ex))
        sys.exit(1)
    else:
        logger.debug('[connect_zapi] Created ZAPI with host [{}:{}]'.format \
                (params['host'], params['port']) )


def poll_snapmirrors():
    """
    Get SnapMirror relationships by their state (insnyce, idle...).
    If possible, store them with their nodes, if node not available,
    store them with associated volumes.

    SnapMirror relationships are either source (incoming) or destination
    (outgoing).

    """

    # Variables to store collected data
    global d_per_nodes, d_per_vols, s_per_nodes, s_per_vols, timestamp

    # destination relationships for which we know the node
    d_per_nodes = {}
    # destination relationships if we don't know the node
    d_per_vols = {}
    # source relationships for which we know the node
    s_per_nodes = {}
    # source relationships for if we don't know the node
    s_per_vols = {}
    timestamp = round(time.time())

    # Construct ZAPI request
    request = SDK.NaElement('snapmirror-get-iter')
    request.child_add_string('max-records', 500)

    next_tag = 'initial'
    count = 0

    # If we get a "next tag", we'll continue polling the server
    while (next_tag):
        if next_tag != 'initial':
            request.child_add_string('tag', next_tag)

        # Send request to server
        try:
            response = zapi.invoke_elem(request)
        except Exception as ex:
            logger.error('[poll_snapmirrors] Exception while sending ZAPI request' \
                ': {}'.format(ex))
            sys.exit(1)

        # Check the results
        if response.results_status() != 'passed':
            logger.error('[poll_snapmirrors] ZAPI request failed: {}'.format \
                (response.results_reason()))
            sys.exit(1)

        # No point to continue if no SM replications on cluster
        if not response.child_get_int('num-records'):
            logger.info('[poll_snapmirrors] No Snapmirror replications on ' \
                'this cluster, stopping session')
            sys.exit(0)

        # This will be None if we got everything already
        next_tag = response.child_get_string('next-tag')

        try:
            snapmirrors = response.child_get('attributes-list').children_get()
        except (NameError, AttributeError) as ex:
            logger.error('[poll_snapmirrors] Extracting results failed: {}'.format(ex))
            sys.exit(1)

        # Iterate over list of snapmirrors
        for sm in snapmirrors:
            state = sm.child_get_string('relationship-status')
            if not state:
                continue

            # Handle destination instances
            d_node = sm.child_get_string('destination-volume-node')
            if d_node:
                if d_node not in d_per_nodes:
                    d_per_nodes[d_node] = {}
                d_per_nodes[d_node][state] = d_per_nodes[d_node].get(state,0) + 1
                count += 1
            # If node not provided, add per volume
            else:
                d_vol = sm.child_get_string('destination-volume')
                if d_vol:
                    if d_vol not in d_per_vols:
                        d_per_vols[d_vol] = {}
                    d_per_vols[d_vol][state] = d_per_vols[d_vol].get(state,0) + 1
                    count += 1
                else:
                    logger.warning('[poll_snapmirrors] Destination relationship	' \
                        'with no node or volume. Skipping')

            # Handle source instances
            # We don't get node, so just add per volume
            s_vol = sm.child_get_string('source-volume')
            if s_vol:
                if s_vol not in s_per_vols:
                    s_per_vols[s_vol] = {}
                s_per_vols[s_vol][state] = s_per_vols[s_vol].get(state,0) + 1
                count += 1
            else:
                logger.warning('[poll_snapmirrors] Source relationship with ' \
                    'no volume. Skipping')

    # Don't continue if nothing was collected
    if not count:
        logger.warning('[poll_snapmirrors] No instances collected, so exiting')
        sys.exit(0)
    else:
        logger.debug('[poll_snapmirrors] Collected {} SnapMirror relationship ' \
            'instances'.format(count))


def poll_nodes():
    """
    For volumes without a node, find the corresponding node.
    """

    global d_per_vols, d_per_nodes, s_per_vols, s_per_nodes

    # Continue only if necessary
    if not d_per_vols and not s_per_vols:
        logger.debug('[poll_nodes] No volumes are missing nodes, skipping poll')
        return

    request = SDK.NaElement('perf-object-get-instances')
    request.child_add_string('objectname', 'volume')

    # Limit request to required volumes, (otherwise we'll get all volumes
    # on the system)
    instances_elem = SDK.NaElement('instances')
    volumes = (list(d_per_vols.keys()) + list(s_per_vols.keys()))
    for vol in set(volumes):
        instances_elem.child_add_string('instance', vol)
    request.child_add(instances_elem)

    # Likewise, limit request to node name, we don't need full list of counters
    counters_elem = SDK.NaElement('counters')
    counters_elem.child_add_string('counter', 'node_name')
    request.child_add(counters_elem)

    # Send request
    try:
        response = zapi.invoke_elem(request)
    except Exception as ex:
        logger.error('[poll_nodes] Exception while sending ZAPI request' \
            ': {}'.format(ex))
        return

    # Check response
    if response.results_status() != 'passed':
        logger.error('[poll_nodes] ZAPI request failed: {}'.format \
            (response.results_reason()))
        return

    # Dig into results
    try:
        data = response.child_get('instances').children_get()
    except (NameError, AttributeError) as ex:
        logger.error('[poll_nodes] Extracting results failed: {}'.format(ex))
        return

    count = 0

    for vol in data:
        volume_name = vol.child_get_string('name')
        # There should be only one counter, but to be on the safe side make
        # sure it's the node we need
        node_name = None
        for counter in vol.child_get('counters').children_get():
            if counter.child_get_string('name') == 'node_name':
                node_name = counter.child_get_string('value')
                break

        if not node_name:
            logger.warning('[poll_nodes] No node name for volume {}, ' \
                'skipping'.format(volume_name))
            continue

        logger.debug('[poll_nodes] {} ===> {}'.format(volume_name, node_name))
        count += 1

        # Move SnapMirror instance from volume to its node
        if vol in d_per_vols:
            if node not in d_per_nodes:
                d_per_nodes[node] = {}
            for state in d_per_vols[vol]:
                d_per_nodes[node][state] = d_per_nodes[node].get(state,0) + d_per_vols[vol][state]

        if vol in s_per_vols:
            if node not in s_per_nodes:
                s_per_nodes[node] = {}
            for state in s_per_vols[vol]:
                s_per_nodes[node][state] = s_per_nodes[node].get(state,0) + s_per_vols[vol][state]

    logger.debug('[poll_nodes] Found nodes for {} volumes'.format(count))

    # Delete volumes since we don't need them anymore
    del s_per_vols
    del d_per_vols


def poll_meters():
    """
    Get the limit on active SnapMirror replications per node
    """

    global d_per_nodes, s_per_nodes

    # Construct our request
    request = SDK.NaElement('perf-object-get-instances')
    request.child_add_string('objectname', 'smc_em')

    # Request for all nodes
    instances_elem = SDK.NaElement('instances')
    instances_elem.child_add_string('instance', '*')
    request.child_add(instances_elem)

    # Limit request to the counters we need
    counters_elem = SDK.NaElement('counters')
    counters_elem.child_add_string('counter', 'node_name')
    counters_elem.child_add_string('counter', 'dest_meter_count')
    counters_elem.child_add_string('counter', 'src_meter_count')
    request.child_add(counters_elem)

    # Send request
    try:
        response = zapi.invoke_elem(request)
    except Exception as ex:
        logger.error('[poll_meters] Error while sending ZAPI request: {}'.format(ex))
        return

    # Check response
    if response.results_status() != 'passed':
        logger.error('[poll_meters] ZAPI request failed: {}'.format \
            (response.results_reason()))
        return

    # Dig into results
    try:
        instances = response.child_get('instances').children_get()
    except (NameError, AttributeError) as ex:
        logger.error('[poll_meters] Extracting results failed: {}'.format(ex))
        return

    count = 0

    for node in instances:
        # store node counters in dict
        n_counters = {}
        for c in node.child_get('counters').children_get():
            n_counters[c.child_get_string('name')] = c.child_get_string('value')

        # Make sure we have the node name
        if 'node_name' not in n_counters:
            logger.warning('[poll_meters] Go instance without node name, skipping')
            continue

        node_name = n_counters['node_name']
        count += 1

        # Add meters to our data
        if 'src_meter_count' in n_counters and node_name in s_per_nodes:
            s_per_nodes[node_name]['meter'] = n_counters['src_meter_count']

        if 'dest_meter_count' in n_counters and node_name in d_per_nodes:
            d_per_nodes[node_name]['meter'] = n_counters['dest_meter_count']

    logger.debug('[poll_meters] Collected meters for {} nodes'.format(count))


def render_graphite_metrics():
    """
    Convert data that we collected to the format that we can send to Graphite
    """

    global graphite_metrics
    graphite_metrics = []
    graphite_root = params['graphite_root'] if 'graphite_root' in params else ''

    # Define the format of the metrics
    def add_metric(node, counter, value):
        M = "{ROOT}.node.{NODE}.snapmirror.{COUNTER} {VALUE} {TS}\n".format \
            (
                ROOT = graphite_root,
                NODE = node,
                COUNTER = counter,
                VALUE = value,
                TS = timestamp
            )
        # Python 3 stores strings as unicode by default
        # so convert to byte array which is required by socket
        if sys.version_info >= (3,0):
            M = M.encode()
        # Add metric to list
        graphite_metrics.append(M)
        logger.debug('[render_graphite_metrics] M={}'.format(M[:-1]))

    # Rewrite collected data as metrics
    for n in d_per_nodes:
        for state in d_per_nodes[n]:
            if state == 'meter':
                counter = 'dest_meter_count'
                value = d_per_nodes[n][state]
            else:
                counter = 'dest.' + state
                value = d_per_nodes[n][state]
            add_metric(n, counter, value)

    for n in s_per_nodes:
        for state in s_per_nodes[n]:
            if state == 'meter':
                counter = 'src_meter_count'
                value = s_per_nodes[n][state]
            else:
                counter = 'src.' + state
                value = s_per_nodes[n][state]
            add_metric(n, counter, value)


def send_to_graphite(is_retry=False):
    """
    Open socket to graphite server and send the metrics
    """

    # If we have no graphite root defind, no need to send metrics
    if 'graphite_root' not in params or params['graphite_root'] == '_':
        logger.debug('[send_to_graphite] Skipping send metrics to graphite')
        return

    # Open socket to Graphite server
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        sock.connect((params['graphite_host'], params['graphite_port']))
    except Exception as ex:
        logger.error('[send_to_graphite] Error while opening socket to ' \
            'Graphite [{}:{}]: {}'.format( params['graphite_host'],
                                           params['graphite_port'],
                                           ex) )
        # Retry one more time
        if not is_retry:
            send_to_graphite(is_retry=True)
        else:
            logger.error('[send_to_graphite] Retry failed, so exiting')
            sys.exit(1)
    else:
        logger.debug('[send_to_graphite] Opened socket to Graphite ' \
                '[{}:{}]'.format( params['graphite_host'],
                                  params['graphite_port']) )

    # Remove timeout to get back to blocking mode
    sock.settimeout(None)

    # Send metrics
    success = 0
    failed = 0
    for metric in graphite_metrics:
        try:
            response = sock.sendall(metric)
        except Exception as ex:
            logger.warning('[send_to_graphite] Error while sending metric: ' \
                '{}'.format(ex))
            failed += 1
        else:
            if response:
                logger.warning('[send_to_graphite] Failed to send metric: ' \
                    '{}'.format(ex))
                failed += 1
            else:
                success += 1

    # Close socket
    sock.shutdown(socket.SHUT_WR)
    sock.close()

    logger.debug('[send_to_graphite] Successfully sent: {}, failed: {}'.format \
        (success, failed))


if __name__ == '__main__':
    main()
