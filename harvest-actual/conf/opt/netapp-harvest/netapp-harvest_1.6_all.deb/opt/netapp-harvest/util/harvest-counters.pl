#!/usr/bin/perl -X
# ======================================================================================================================
# NetApp Harvest - Utilities
# ======================================================================================================================
#
# name:		harvest-counters.pl
#
# type:	 	perl script (main)
#
# purpose:	tool to retrieve or check objects and counters in a given template
#
# parameters:	(see routine PrintHelp() for details)
#
# author:	Georg Mey 
#
# copyright:	Georg Mey
#
# ------------------------------------------------------------------------------
# open points:
#
# ======================================================================================================================

# ------------------------------------------------------------------------------
# module import section
# ------------------------------------------------------------------------------
use Getopt::Long qw(:config pass_through);
use POSIX qw(strftime);

# ======================================================================================================================
# subroutine:	PrintHelp
#
# parameter:	-none-
# purpose:	show help message and abort
# ======================================================================================================================
sub PrintHelp {

    print <<EOF;


   $MyName [general_options] command subcommand [command_options] 


   general_options:	
	
      -raw                       raw mode - do not print headers etc.
      -debug                     write debug message (for testing only)
      -help|-h                   show this screen
      -version|-v                show internal program version number

   commands/subcommands supported:

      list  object               list all objects
      list  counter              list all counters
      list  plugin               list all plugins
      check object               check if object exists
      check counter              check if counter exists

   command_options:

      -template | -t <template file>
      -object   | -o <object_name>
      -counter  | -c <counter_name>


EOF
  
}

# ======================================================================================================================
# subroutine:   ListObject
#
# parameter:    -none-
# purpose:      list all objects for select template
# ======================================================================================================================
sub ListObject {


	$i=0;

	if ( ! $RawMode ) {
		printf ("\n");
		printf ("%-30.30s\n","object");
		printf ("%-30.30s\n",$Dashes);
	}

	for $object ( sort keys %poller ) {

		printf ("%-30.30s\n",$object);
		$i++

	}

	if ( ! $RawMode ) {
		printf ("%-30.30s\n",$Dashes);
		printf ("%d entries found\n",$i);
		printf ("\n");
	}

}

# ======================================================================================================================
# subroutine:   Listcounter
#
# parameter:    -none-
# purpose:      list all counters of all objects for select template
# ======================================================================================================================
sub ListCounter {


	$i=0;

	if ( ! $RawMode ) {
		printf ("\n");
		printf ("%-30.30s ","object");
		printf ("%-30.30s\n","counter");
		printf ("%-30.30s ",$Dashes);
		printf ("%-30.30s\n",$Dashes);
	}

	for $object ( sort keys %poller ) {

		if ( $ObjectName eq "" || $ObjectName eq $object ) {

			for $j ( 0 .. $#{ $poller{$object}{"counter_list"} } ) {

				printf ("%-30.30s %-30.30s\n",$object,$poller{$object}{"counter_list"}[$j]);
				$i++;
			}
		}


	}

	if ( ! $RawMode ) {
		printf ("%-30.30s ",$Dashes);
		printf ("%-30.30s\n",$Dashes);
		printf ("%d entries found\n",$i);
		printf ("\n");
	}

}

# ======================================================================================================================
# subroutine:   ListPlugin
#
# parameter:    -none-
# purpose:      list plugin (if any) of a given object - or all objects
# ======================================================================================================================
sub ListPlugin {


	$i=0;

	if ( ! $RawMode ) {
		printf ("\n");
		printf ("%-30.30s ","object");
		printf ("%-30.30s\n","plugin");
		printf ("%-30.30s ",$Dashes);
		printf ("%-30.30s\n",$Dashes);
	}

	for $object ( sort keys %poller ) {

		if ( $ObjectName eq "" || $ObjectName eq $object ) {

			 if ( exists $poller{$object}{"plugin"} ) {

				printf ("%-30.30s %-30.30s\n",$object,$poller{$object}{"plugin"});
				$i++;

			} else {
				printf ("%-30.30s %-30.30s\n",$object,"-none-");

			}
		}


	}

	if ( ! $RawMode ) {
		printf ("%-30.30s ",$Dashes);
		printf ("%-30.30s\n",$Dashes);
		printf ("%d entries found\n",$i);
		printf ("\n");
	}

}


# ======================================================================================================================
# subroutine:   CheckCounter
#
# parameter:    -none-
# purpose:      check if object is defined in template
# ======================================================================================================================
sub CheckCounter {

	$Response = "false";

	if ( defined $poller{$ObjectName} ) {

		for $j ( 0 .. $#{ $poller{$ObjectName}{"counter_list"} } ) {
			if ( $poller{$ObjectName}{"counter_list"}[$j] eq $CounterName ) { $Response = "true" }
		}

	}

	printf ("%s\n",$Response);

}

# ======================================================================================================================
# subroutine:   CheckObject
#
# parameter:    -none-
# purpose:      check if counter for given object is defined in template
# ======================================================================================================================
sub CheckObject {

	if ( defined $poller{$ObjectName} ) {
		printf ("true\n");
	} else {
		printf ("false\n");
	}

}

# ======================================================================================================================
# subroutine:   <command><subcommand>Check
#
# parameter:    -none-
# purpose:      checks for vital parameters needed to handle the command
# ======================================================================================================================
sub Check {

    PrintHelp;
    exit(0);

}

sub ListObjectCheck { 

    my @Messages;

    if ( $Template    eq "" ) { push @Messages,"[" . $MyName . "] no template specified" }

    if ( $#Messages > -1 ) {
        print  join("\n",@Messages);
        printf ("\n[" . $MyName . "] see --help for details\n");
        return (2);
    }
    return (1);

}

sub ListCounterCheck { 

    my @Messages;

    if ( $Template    eq "" ) { push @Messages,"[" . $MyName . "] no template specified" }

    if ( $#Messages > -1 ) {
        print  join("\n",@Messages);
        printf ("\n[" . $MyName . "] see --help for details\n");
        return (2);
    }
    return (1);

}

sub ListPluginCheck { 

    my @Messages;

    if ( $Template    eq "" ) { push @Messages,"[" . $MyName . "] no template specified" }

    if ( $#Messages > -1 ) {
        print  join("\n",@Messages);
        printf ("\n[" . $MyName . "] see --help for details\n");
        return (2);
    }
    return (1);

}

sub CheckObjectCheck {

    my @Messages;

    if ( $Template    eq "" ) { push @Messages,"[" . $MyName . "] no template specified" }
    if ( $ObjectName  eq "" ) { push @Messages,"[" . $MyName . "] no object specified" }

    if ( $#Messages > -1 ) {
        print  join("\n",@Messages);
        printf ("\n[" . $MyName . "] see --help for details\n");
        return (2);
    }
    return (1);

}

sub CheckCounterCheck {

    my @Messages;

    if ( $Template    eq "" ) { push @Messages,"[" . $MyName . "] no template specified" }
    if ( $ObjectName  eq "" ) { push @Messages,"[" . $MyName . "] no object specified" }
    if ( $CounterName eq "" ) { push @Messages,"[" . $MyName . "] no counter specified" }

    if ( $#Messages > -1 ) {
        print  join("\n",@Messages);
        printf ("\n[" . $MyName . "] see --help for details\n");
        return (2);
    }
    return (1);

}

# ======================================================================================================================
# subroutine:	PrintVersion
#
# parameter:	-none-
# purpose:	display current version of script
# ======================================================================================================================
sub PrintVersion {

	printf("version A.01.01 (build 1, 2019.02.16)\n");

}

# ----------------------------------------------------------------------------------------------------------------------
# local varibales
# ----------------------------------------------------------------------------------------------------------------------
our $MyName	= 'harvest-counters.pl';	# program's name
our $MyBlks	= $MyName;			# sequence of blanks with same
    $MyBlks =~ s/./ /g;				# length as program name

# - runstring parameter values -----------------------------------------------------------------------------------------

our $RawMode		= "";			# enhanced messages for log file
our $DebugMode		= "";			# switch for debug messages
our $HelpMode		= 0;			# show command line help
our $VersionMode	= 0;			# show version of program

our @SavedArgs		= @ARGV;		# save all arguments

our $ObjectName		= "";
our $CounterName	= "";
our $Template		= "";
our $Dashes		= "---------------------------------------------------------------------------------------";

# ----------------------------------------------------------------------------------------------------------------------
# runstring parameter passing
# ----------------------------------------------------------------------------------------------------------------------

my $Command		= $SavedArgs[0];
my $SubCommand		= $SavedArgs[1];

GetOptions (
            'raw'    			=> \$RawMode,
            'r'    			=> \$RawMode,
            'debug'    			=> \$DebugMode,
            'help'       		=> \$HelpMode,
            'h'          		=> \$HelpMode,
            'version'    		=> \$VersionMode,
            'v' 	   		=> \$VersionMode,
            'template:s'                => \$Template,
            't:s'                  	=> \$Template,
            'object:s'                  => \$ObjectName,
            'o:s'                  	=> \$ObjectName,
            'counter:s'                 => \$CounterName,
            'c:s'                 	=> \$CounterName);

if ( $HelpMode ) {
	PrintHelp; 
	exit(0);
}

if ( $VersionMode ) {
	PrintVersion; 
	exit(0);
}

# ----------------------------------------------------------------------------------------------------------------------
# runstring parameter passing
# ----------------------------------------------------------------------------------------------------------------------

if ( -r $Template ) { do $Template }

# ======================================================================================================================
# main body of program
# ======================================================================================================================

if ( $DebugMode ) {
	printf (DEBUG "[debug] processing command %s %s\n",$Command,$SubCommand);
}

my $SubRoutine   = ucfirst $Command . ucfirst $SubCommand;
my $CheckRoutine = $SubRoutine . "Check";

if (exists &{$SubRoutine}) {

	if ( (eval $CheckRoutine) == 1 ) { eval $SubRoutine }

} else {

	PrintHelp;
	exit(2);

}

# ======================================================================================================================
# END of perl script
# ======================================================================================================================
